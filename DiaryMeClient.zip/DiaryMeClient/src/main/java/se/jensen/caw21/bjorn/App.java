package se.jensen.caw21.bjorn;

public class App {
    public static void main( String[] args ) {
        MyProgram myProgram = new MyProgram();
        myProgram.start();
    }
}