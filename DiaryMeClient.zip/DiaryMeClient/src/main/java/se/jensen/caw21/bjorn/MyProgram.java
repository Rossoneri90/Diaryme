package se.jensen.caw21.bjorn;

import java.util.ArrayList;
import java.util.Scanner;

public class MyProgram {
    private myApiClient myApiClient;
    // private ArrayList<BlogPosts> myBlogPosts = new ArrayList<>();


    // With the help of a constructor we are able to establish a ApiClient
    public MyProgram() {
        myApiClient = new myApiClient("http://127.0.0.1:8080/api/v1");
    }

    // This is where the program stars running
    public void start() {
        boolean programRunning = true;

        // This is how the meny will be presented. Witch options will be aviable.
        // I'm using a switch case to present the options and a getuserint to have the user choose.
        while (programRunning) {
            System.out.println();
            System.out.println("=========================================");

            System.out.println("Welcome. What would you like to do?");
            System.out.println("1. Add a blogpost.");
            System.out.println("2. Get list of blogposts.");
            System.out.println("3. Clear list of blogposts.");
            System.out.println("4. Remove blogpost.");
            System.out.println("5. Search blogpost by ID.");
            System.out.println("6. Update blogpost.");
            System.out.println("7. Exit program.");
            System.out.println("=========================================");
            System.out.println();

            int userChoice = getUserInt();

            System.out.println("User picked: " + userChoice);

            switch (userChoice) {
                case 1:
                    addBlogPosts();
                    break;
                case 2:
                    printListOfBlogPosts();
                    break;
                case 3:
                    clearListOfBlogPosts();
                    break;
                case 4:
                    removeBlogPost();
                    break;
                case 5:
                    viewBlogPostsByID();
                    break;
                case 6:
                    updateBlogByID();
                    break;
                case 7:
                    System.out.println("Goodbye.");
                    programRunning = false;

            }
        }
    }

    // This is a method to get the list of the blogpost using the ApiClient.
    public void printListOfBlogPosts() {
        BlogPosts[] blogposts = myApiClient.getBlogPosts();

        System.out.println("Blogposts");
        System.out.println("-----------------------------------------");

        if (blogposts.length > 0) {
            for (int i = 0; i < blogposts.length; i++) {
                int ID = blogposts[i].getID();
                String body = blogposts[i].getTitle();

                System.out.printf("%s\n", ID);
                System.out.printf("%s\n", body);
            }
        } else {
            System.out.println("No blogposts in list :(");
        }
    }

    // This is a metod that allows us to clear the list of blogposts
    public void clearListOfBlogPosts() {

        if (myApiClient.clearBlogPosts()) {
            System.out.println("All blogposts got deleted");
        } else {
            System.out.println("Error, the list is not cleared.");
        }
    }

    // Add a blogpost by adding a title and a body, an ID to the blogpost is provided by creating a title and body.
    public void addBlogPosts() {

        System.out.println("What's the blogposts called?");
        String title = getUserString();

        System.out.println("What do you wish to write?");
        String body = getUserString();


        BlogPosts newBlogPost = new BlogPosts(title, body);

        boolean success = myApiClient.addBlogPost(newBlogPost);

        if (success) {
            System.out.println("Blogpost added!");
        } else {
            System.out.println("Issue adding blogpost. :(");
        }

    }

    // An metod that saves and uses the users command.
    public String getUserString() {
        Scanner myScanner = new Scanner(System.in);

        String myString;

        while (true) {
            try {
                System.out.print("> ");
                myString = myScanner.nextLine();
                break;
            } catch (Exception e) {
                //System.out.println("Exception: " + e);
                System.out.println("Error");
            }
        }

        return myString;
    }

    // An metod that saves and uses the users command.
    public int getUserInt() {
        Scanner myScanner = new Scanner(System.in);

        int myInteger;

        while (true) {
            try {
                System.out.print("> ");
                myInteger = Integer.parseInt(myScanner.nextLine());
                break;
            } catch (Exception e) {
                //System.out.println("Exception: " + e);
                System.out.println("Error");
            }
        }

        return myInteger;
    }

    // An metod that removes an blogpost, user needs an ID to identify the proper blogpost.
    public void removeBlogPost() {


        System.out.println("What blogpost do you wish to remove?");
        int searchID = getUserInt();


        boolean success = myApiClient.deleteBlogPosts(searchID);
        if (success) {
            System.out.println("Your blogpost have been deleted");
        } else {
            System.out.println("No blogposts in list with that ID no.");
        }
    }

    // Update an blogpost by replacing the title and the body of the blogpost, ID remains unchangeable
    // Behöver hjälp
    private void updateBlogByID() {

        System.out.println("Witch blogpost do you wish to update" + "\n" + "Type the ID no of the blogpost");

        int searchIDD2 = getUserInt();
        BlogPosts myBlogpost = myApiClient.viewBlogPostsByID(searchIDD2);

        if (myBlogpost != null) {

            System.out.println("Write the new title");
            String titleUpdate = getUserString();
            myBlogpost.setTitle(titleUpdate);
            // myBlogPosts.get(j).setTitle(getUserString());
            //  System.out.println("The new title is:" + " " + (myBlogPosts.get(j).getTitle()));

            System.out.println("Write the new body");
            String bodyUpdate = getUserString();
            myBlogpost.setBody(bodyUpdate);
            //myBlogPosts.get(j).setBody(getUserString());
            //System.out.println("The new body is:" + " " + (myBlogPosts.get(j).getBody()));

            myApiClient.updateBlogPost(searchIDD2, myBlogpost);
        }

     else{
            System.out.println("Error, the update went wrong.");
        }
    }

    private void viewBlogPostsByID() {

        System.out.println("Witch blogpost do you wish to list" + "\n" + "Type the ID no of the blogpost");
        int searchIDD2 = getUserInt();

        BlogPosts myBlogpost = myApiClient.viewBlogPostsByID(searchIDD2);

        System.out.println("Blogposts");
        System.out.println("-----------------------------------------");

        // boolean success = myApiClient.viewBlogPostsByID(searchIDD2);

        if (myBlogpost != null) {

            int ID = myBlogpost.getID();
            String title = myBlogpost.getTitle();
            String body = myBlogpost.getBody();

            System.out.printf("%s\n", ID);
            System.out.printf("%s\n", title);
            System.out.printf("%s\n", body);

        } else {
            System.out.println("No blogposts in list with that ID :(");
        }
    }

}
