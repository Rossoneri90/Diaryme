package se.jensen.caw21.bjorn;

// These are the packages we use to read  and write information to HTTP-connections.

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;

// This gives us the access to convert JSON data to readable code for Java.
import com.fasterxml.jackson.databind.*;

// This is used to send data with UFT-8 - an edit that allows the user to use different types.
import java.nio.charset.StandardCharsets;

// Packages used to achieve HTTP-Connections.
import java.net.URL;
import java.net.HttpURLConnection;

public class myApiClient {
    // Adress to our server, https://127.0.0.1:8080/api/v1
    private String apiAddress;
    HttpURLConnection connection;

    // A constructor for the ApiClient.
    public myApiClient(String apiAddress) {
        this.apiAddress = apiAddress;
    }
    // A method to get the blogposts.
    public BlogPosts[] getBlogPosts() {
        BlogPosts[] blogposts = {};

        String target = "/blog/list";

        BufferedReader reader;
        String line;
        StringBuilder responseContent = new StringBuilder();

        // Generates a URL-object and the adress we want to send it to.
        // Opens up the network connection.
        // Requests method.
        // Request to send JSON data.
        try {
            URL url = new URL(apiAddress + target);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("accept", "application/json");

            int status = connection.getResponseCode();

            if (status >= 300) {
                reader = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
                while ((line = reader.readLine()) != null) {
                    responseContent.append(line);
                }
                reader.close();
            } else {
                reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                while ((line = reader.readLine()) != null) {
                    responseContent.append(line);
                }
                reader.close();
            }

            String jsonStr = responseContent.toString();

            ObjectMapper mapper = new ObjectMapper();
            blogposts = mapper.readValue(jsonStr, BlogPosts[].class);

        } catch (Exception e) {
            System.out.println("Exception: " + e);
        } finally {
            connection.disconnect();
        }

        return blogposts;
    }
    // A metod to clear all the blogpost.
    public boolean clearBlogPosts() {

        String target = "/blog/clear"; // http://127.0.0.1:8080/api/v1/movies/clear

        //Delets blogposts from apiAddress + target);

        boolean success = false;

        // Generates a URL-object and the adress we want to send it to.
        // Opens up the network connection.
        // Requests method.
        // Request to send JSON data.
        try {
            URL url = new URL(apiAddress + target);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("DELETE");

            int status = connection.getResponseCode();

            if (status < 300) {
                success = true;
            }

            //Response content toString.
        } catch (Exception e) {
            System.out.println("Exception: " + e);
        } finally {
            connection.disconnect();
        }

        return success;
    }
    // A metod to delete a specific blogpost.
    public boolean deleteBlogPosts(int id) {

        String target = "/blog/delete/" + id;

        System.out.println("deleting blogpost from" + apiAddress + target);
        //Deletes blogposts from apiAddress + target);

        boolean success = false;

        // Generates a URL-object and the adress we want to send it to.
        // Opens up the network connection.
        // Requests method.
        // Request to send JSON data.
        try {
            URL url = new URL(apiAddress + target);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("DELETE");

            int status = connection.getResponseCode();
            System.out.println("Status response" + status);
            if (status < 300) {
                success = true;
            }

            //Response content toString.
        } catch (Exception e) {
            System.out.println("Exception: " + e);
        } finally {
            connection.disconnect();
        }

        return success;
    }
    // A metod that adds a blogpost.
    public boolean addBlogPost(BlogPosts newBlogPost) {
        String target = "/blog/create";

        // Adding movie at apiAddress and target.

        boolean success = false;

        try {

            // Generates a URL-object and the adress we want to send it to.
            // Opens up the network connection.
            // Requests method.
            // Request to send JSON data.

            URL url = new URL(apiAddress + target);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json; utf-8");
            connection.setDoOutput(true);

            // Converts the Java object to JSON.
            // Using network connection the JSON data sends to a OutputStream.
            try (OutputStream os = connection.getOutputStream()) {
                byte[] input = newBlogPost.toJson().getBytes(StandardCharsets.UTF_8);

                os.write(input, 0, input.length);
            }
            int status = connection.getResponseCode();

            if (status < 300) {
                success = true;
            }

            // ResponseContent toString.
        } catch (Exception e) {
            System.out.println("Exception: " + e);
        } finally {
            connection.disconnect();
        }

        return success;
    }
    // A method to update blogposts.
    public boolean updateBlogPost(int ID, BlogPosts updateBlogPost) {

        String target = "/blog/update/" + ID;

        boolean success = false;

        // Generates a URL-object and the adress we want to send it to.
        // Opens up the network connection.
        // Requests method.
        // Request to send JSON data.
        try {
            // Generates a URL-object and the adress we want to send it to.
            URL url = new URL(apiAddress + target);

            // Opens up the network connection.
            // Requests method.
            // Request to send JSON data.
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json; utf-8");
            connection.setDoOutput(true);

            // Converts the Java object to JSON.
            // Using network connection the JSON data sends to a OutputStream.
            try (OutputStream os = connection.getOutputStream()) {
                byte[] input = updateBlogPost.toJson().getBytes(StandardCharsets.UTF_8);

                os.write(input, 0, input.length);
            }

            int status = connection.getResponseCode();

            if (status < 300) {
                success = true;
            }

            // ResponseContent toString.
        } catch (Exception e) {
            System.out.println("Exception: " + e);
        } finally {
            connection.disconnect();
        }

        return success;
    }
    // A method to view a specific blogpost.
    public BlogPosts viewBlogPostsByID(int ID) {

        String target = "/blog/view/" + ID;
        BlogPosts blogposts = null;

        System.out.println("Getting blogposts from " + apiAddress + target);

        BufferedReader reader;
        String line;
        StringBuilder responseContent = new StringBuilder();

        // Generates a URL-object and the adress we want to send it to.
        // Opens up the network connection.
        // Requests method.
        // Request to send JSON data.
        try {
            URL url = new URL(apiAddress + target);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("accept", "application/json");

            int status = connection.getResponseCode();
            System.out.println("HTTP status" + status);
            if (status >= 300) {
                reader = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
                while ((line = reader.readLine()) != null) {
                    responseContent.append(line);
                }
                reader.close();
            } else {
                reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                while ((line = reader.readLine()) != null) {
                    responseContent.append(line);

                }
                reader.close();
                // Saves the responsecontent toString.
                String jsonStr = responseContent.toString();

                // Transforms JSON String to readable java code
                ObjectMapper mapper = new ObjectMapper();
                blogposts = mapper.readValue(jsonStr, BlogPosts.class);
            }



        } catch (Exception e) {
            System.out.println("Exception: " + e);
            e.printStackTrace();
        } finally {
            connection.disconnect();
        }

        return blogposts;
    }
}
