// Imported packages
package se.jensen.caw21.bjorn;

import java.io.StringWriter;
import java.io.Writer;

import com.github.cliftonlabs.json_simple.JsonObject;
import com.github.cliftonlabs.json_simple.JsonKey;
import com.github.cliftonlabs.json_simple.Jsonable;

// Constructors for the object blogpost
public class BlogPosts implements Jsonable {
    public int id;
    public String title;
    public String body;

    public BlogPosts(String titleUpdate, String bodyUpdate) {
        this.title = titleUpdate;
        this.body = bodyUpdate;

    }

    enum keys implements JsonKey {
        ID("id"),
        TITLE("title"),
        BODY("body");

        private final Object value;

        /**
         * Instantiates a JsonKey with the provided value.
         *
         * @param value represents a valid default for the key.
         */
        keys(final Object value) {
            this.value = value;
        }

        @Override
        public String getKey() {
            return this.name().toLowerCase();
        }

        @Override
        public Object getValue() {

            return this.value;
        }

    }
// Constructor used as a blueprint to what a blogpost contains.
    public BlogPosts(int id, String title, String body) {
        this.id = id;
        this.title = title;
        this.body = body;
    }

    private BlogPosts() {
//        this.id = (Integer) keys.ID.getValue();
        this.title = (String) keys.TITLE.getValue();
        this.body = (String) keys.BODY.getValue();
    }

    // Getter that provides the program with an ID.
    public int getID() {
        return id;
    }

    // Setter that provides the program with an ID
    public void setId(int id) {
        this.id = id;
    }

    // Getter that provides the program with an body.
    public String getBody() {
        return body;
    }

    // Setter that provides the program with an body.
    public void setBody(String body) {
        this.body = body;
    }

    // Getter that provides the program with an title.
    public String getTitle() {
        return title;
    }

    // Setter that provides the program with an body.
    public void setTitle(String title) {
        this.title = title;
    }

    // Polymorph that connects to the server
    @Override
    public String toJson() {
        final StringWriter writable = new StringWriter();
        try {
            this.toJson(writable);
        } catch (final Exception e) {

        }
        return writable.toString();
    }

    @Override
    public void toJson(final Writer writable) {
        try {
            final JsonObject json = new JsonObject();
            json.put(keys.TITLE.getKey(), this.getTitle());
            json.put(keys.BODY.getKey(), this.getBody());
            json.put(keys.ID.getKey(), this.getID());
            json.toJson(writable);
        } catch (Exception e) {
            System.out.println("Exception: " + e);
        }
    }
    // Polymorph that returns an object
    @Override
    public String toString() {
        return "[id=" + this.id + ", title=" + this.title + ", body=" + this.body + "]";
    }
}