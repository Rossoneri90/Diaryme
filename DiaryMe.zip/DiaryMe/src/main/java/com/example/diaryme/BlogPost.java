package com.example.diaryme;

public class BlogPost {
    private int id;
    private String body;
    private String title;

    // Getter that provides the program with an ID.
    public int getId() {
        return id;
    }

    // Setter that provides the program with an ID.
    public void setId(int id) {
        this.id = id;
    }

    // Getter that provides the program with an body
    public String getBody() {
        return body;
    }

    // Setter that provides the program with an body
    public void setBody(String body) {
        this.body = body;
    }

    // Getter that provides the program with a title.
    public static String getTitle() {
        return getTitle();
    }

    // Setter that provides the program with a title.
    public void setTitle(String title) {
        this.title = title;
    }


    @Override
    public String toString() {
        return "Movie{" +
                "id=" + id +
                ", body=" + body +
                ", title='" + title + '\'' +
                '}';
    }

}
