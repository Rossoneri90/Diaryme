


package com.example.diaryme;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController
@RequestMapping(value = "api/v1/blog")
public class BlogController {

    // Arraylist for blogposts.
    ArrayList<BlogPost> myBlogPosts;

    // An counter for number of blogposts.
    int latestBlogPostID;

    public BlogController() {
        myBlogPosts = new ArrayList<BlogPost>();
        latestBlogPostID = 0;
    }


    // Creates a new blogpost by sending this infomartion in JSON-format to our HTTP-request in Insomnia
    @RequestMapping(value = "create", method = RequestMethod.POST)
    public ResponseEntity<BlogPost> createBlogPost(@RequestBody BlogPost blog) {

        if (BlogPost.getTitle() == "") {
            return new ResponseEntity(HttpStatus.BAD_REQUEST);
        } else {

            latestBlogPostID++;
            blog.setId(latestBlogPostID);
            myBlogPosts.add(blog);
            System.out.println("You have added a blogpost.");
            return new ResponseEntity<BlogPost>(blog, HttpStatus.CREATED);
        }
    }

    // Provides an list of the blogposts
    @RequestMapping(value = "list", method = RequestMethod.GET)
    public ResponseEntity<BlogPost> listBlogPosts(@PathVariable("id") int id) {
        System.out.println(myBlogPosts);


        return new ResponseEntity<BlogPost>(HttpStatus.FOUND);
    }

    // Lists an specific blogpost
    @RequestMapping(value = "view/{id}", method = RequestMethod.GET)
    public ResponseEntity<BlogPost> getBlogPost(@PathVariable("id") int id) {
        System.out.println("Getting Blogpost with id " + id);

        BlogPost fetchedBlogPost = getBlogPostByID(id);

        if (fetchedBlogPost == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<BlogPost>(fetchedBlogPost, HttpStatus.OK);
    }

    // Update an blogpost using JSON-format to our HTTP-request in Insomnia
    //  Information sends to this adress http://127.0.0.1:8080/api/v1/movies/update/6.
    @RequestMapping(value = "update/{id}", method = RequestMethod.POST)
    public BlogPost updateBlogPosts(@PathVariable("id") int id, @RequestBody BlogPost BlogChanges) {
        BlogChanges.setId(id);
        System.out.println("Getting blogpost with id " + id);
        BlogPost BlogToUpdate = getBlogPostByID(id);

        if (BlogChanges.getTitle() != null) {
            BlogToUpdate.setTitle(BlogChanges.getTitle());
        }
        if (BlogChanges.getBody() != null) {
            BlogToUpdate.setBody(BlogChanges.getBody());
        }

        updateBlogByID(id, BlogToUpdate);

        return BlogToUpdate;
    }

    // Pulls the list of blogposts using the ID.
    private BlogPost getBlogPostByID(int id) {
        for (int i = 0; i < myBlogPosts.size(); i++) {
            BlogPost currentBlogPost = myBlogPosts.get(i);
            if (currentBlogPost.getId() == id) {
                return myBlogPosts.get(i);
            }
        }

        return null;
    }

    // Get a blogpost with a specific ID and update the blogpost.
    private BlogPost updateBlogByID(int id, BlogPost updatedBlog) {
        for (int i = 0; i < myBlogPosts.size(); i++) {
            BlogPost currentBlogPost = myBlogPosts.get(i);
            if (currentBlogPost.getId() == id) {
                myBlogPosts.set(i, updatedBlog);
                return myBlogPosts.get(i);
            }
        }

        return null;
    }

    // Delete an specific blogpost using an ID.
    @RequestMapping(value = "delete/{id}", method = RequestMethod.DELETE)
    public void deleteBlogPost(@PathVariable("id") int id) {
        deleteBlogPostByID(id);
        System.out.println("Blogpost was deleted.");

    }

    // Method to clear the entire list of blogposts
    @RequestMapping(value = "clearListOfBlogPosts", method = RequestMethod.DELETE)
    public void deleteBlogPost() {

        myBlogPosts.clear();

        System.out.println("All blogposts are deleted.");

    }

    // Method for deleting a specific blogpost using ID.
    private void deleteBlogPostByID(int id) {
        for (int i = 0; i < myBlogPosts.size(); i++) {
            BlogPost currentBlogPost = myBlogPosts.get(i);
            if (currentBlogPost.getId() == id) {
                myBlogPosts.remove(i);
                System.out.println("Ditt bloginlägg är bortaget");

            }
        }


    }

}