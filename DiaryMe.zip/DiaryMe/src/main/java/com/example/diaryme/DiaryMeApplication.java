package com.example.diaryme;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiaryMeApplication {

    public static void main(String[] args) {
        SpringApplication.run(DiaryMeApplication.class, args);
    }

}
