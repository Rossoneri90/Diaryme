package com.example.diaryme;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiaryMeApplicationTests {

    @Test
    void contextLoads() {
    }

}
