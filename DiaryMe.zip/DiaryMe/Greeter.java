package com.example.diaryme;

import org.springframework.web.bind.annotation.RestController;
// Greeter used to greet the user.
@RestController
public class Greeter {

    @RequestMapping (value = "api/greeting/{name}")
    public String getGreeting () {
        return "Welcome to my DiaryMe";
    }
}